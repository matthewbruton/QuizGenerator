package application;

import javafx.scene.Node;

public interface NodeWrapperADT {

//  public Node node = new Node;
  
}
