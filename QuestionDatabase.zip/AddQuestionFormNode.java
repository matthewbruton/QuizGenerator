package application;

import javafx.scene.Node;

public class AddQuestionFormNode implements NodeWrapperADT {

  @Override
  public Node node() {
    // TODO Auto-generated method stub
    return null;
  }

}
